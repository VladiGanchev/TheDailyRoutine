<h1>My Habits</h1>
<script>
    import { post } from '$lib/api';
    import { onMount } from 'svelte';

    let myHabits = [];
    let loading = true;
    let error = null;

    onMount(async () => {
        try {
            myHabits = await post('/api/habits/my', {}); // Fetch user's habits
        } catch (err) {
            error = err.message;
        } finally {
            loading = false;
        }
    });

    const handleDeleteHabit = async (habitId) => {
        try {
            await post(`/api/habits/delete/${habitId}`, {}); // Call delete endpoint
            myHabits = myHabits.filter(habit => habit.id !== habitId); // Update local array
        } catch (err) {
            error = err.message;
        }
    };
</script>

<div class="habit-list-container">
    {#if loading}
        <p>Loading your habits...</p>
    {:else if error}
        <p style="color: red;">Error: {error}</p>
    {:else if myHabits.length === 0}
        <p>You haven't added any habits yet.</p>
    {:else}
        <h2>My Habits</h2>
        <div class="habit-cards">
            {#each myHabits as habit}
                <div class="habit-card">
                    <div class="card-content">
                        <h3 class="habit-title">{habit.title}</h3>
                        <p class="habit-description">{habit.description}</p>
                    </div>
                    <div class="habit-actions">
                        <button class="delete-btn" title="Delete Habit" on:click={() => handleDeleteHabit(habit.id)}>
                            Delete
                        </button>
                        </div>
                </div>
            {/each}
        </div>
    {/if}
</div>

<style>
    /* Reuse styles from PickHabits.svelte, or define new ones if needed */
    .habit-list-container {
        margin: 2rem auto;
        background-color: #2d2d2d;
        border-radius: 8px;
        color: white;
        max-width: 85%;
    }

    h2 {
        font-size: 1.8rem;
        margin: 1rem 0;
        border-bottom: 1px solid #444;
        padding-bottom: 0.5rem;
        text-align: center;
    }

    .habit-cards {
        display: flex;
        flex-wrap: wrap;
        padding: 1rem;
        max-width: 100%;
        justify-content: center;
    }

    .habit-card {
        background-color: #1e1e1e;
        border: 1px solid #333;
        border-radius: 8px;
        width: 18rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        transition: transform 0.2s ease-in-out;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding: 1rem;
        margin: 1rem;
    }

    .habit-card:hover {
        transform: translateY(-5px);
        border-color: #00bcd4;
    }

    .card-content {
        text-align: left;
    }

    .habit-title {
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        font-weight: bold;
    }

    .habit-description {
        font-size: 0.95rem;
        color: #aaa;
    }
        .habit-actions{
                display: flex;
                justify-content: center;
        }
    .delete-btn {
        background-color: #d32f2f; /* Red color for delete */
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.2s ease-in-out;
        margin-top: 10px;
    }

    .delete-btn:hover {
        background-color: #b71c1c;
    }
</style>